class eload:
    def load_extension_meta():
        return {
            "name": "Extension Magic",
            "description": "A magical extension.",
            "version": "1.0.0",
            "author": "Gradio",
            "author_email": "na",
            "url": "https://gradio.app"
        }
        
        
        