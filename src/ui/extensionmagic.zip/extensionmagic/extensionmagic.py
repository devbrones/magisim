def run_extension():
    return "Hello from ExtensionMagic, i am run in a function!"