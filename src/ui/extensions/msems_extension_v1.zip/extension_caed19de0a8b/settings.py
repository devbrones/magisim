class Settings:
    max_iterations: int = 1000
    grid_max_size_x: int = 1000
    grid_max_size_y: int = 1000
    grid_max_size_z: int = 1000


